define([], function() {
    return [].slice;
});