define([], function() {
    return 0;
});