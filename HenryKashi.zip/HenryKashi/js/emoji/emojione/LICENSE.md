#### EmojiOne Artwork

*  Applies to all PNG files found in the emojione-assets repo as well as any adaptations made.
*  Free license: [emojione.com/developers/free-license](https://www.emojione.com/developers/free-license)
*  Premium license: [emojione.com/developers/premium-license](https://www.emojione.com/developers/premium-license)


#### EmojiOne Non-Artwork

*  Applies to the Javascript, JSON, PHP, CSS, HTML files, and everything else not covered under the artwork license above, found in both the emojione and emojione-assets repos.
*  License: MIT
*  Complete Legal Terms: http://opensource.org/licenses/MIT
